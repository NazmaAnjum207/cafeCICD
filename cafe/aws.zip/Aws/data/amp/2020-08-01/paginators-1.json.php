<?php
// This file was auto-generated from sdk-root/src/data/amp/2020-08-01/paginators-1.json
return [ 'pagination' => [ 'ListRuleGroupsNamespaces' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'ruleGroupsNamespaces', ], 'ListScrapers' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'scrapers', ], 'ListWorkspaces' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'workspaces', ], ],];
