<?php
// This file was auto-generated from sdk-root/src/data/mediapackagev2/2022-12-25/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [],];
