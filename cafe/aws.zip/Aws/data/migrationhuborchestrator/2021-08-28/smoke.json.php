<?php
// This file was auto-generated from sdk-root/src/data/migrationhuborchestrator/2021-08-28/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [],];
