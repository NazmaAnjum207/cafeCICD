<?php
// This file was auto-generated from sdk-root/src/data/migrationhuborchestrator/2021-08-28/waiters-2.json
return [ 'version' => 2, 'waiters' => [],];
