<?php
// This file was auto-generated from sdk-root/src/data/qapps/2023-11-27/paginators-1.json
return [ 'pagination' => [ 'ListLibraryItems' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'limit', 'result_key' => 'libraryItems', ], 'ListQApps' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'limit', 'result_key' => 'apps', ], ],];
