<?php
// This file was auto-generated from sdk-root/src/data/observabilityadmin/2018-05-10/paginators-1.json
return [ 'pagination' => [ 'ListResourceTelemetry' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'TelemetryConfigurations', ], 'ListResourceTelemetryForOrganization' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'TelemetryConfigurations', ], ],];
