<?php
// This file was auto-generated from sdk-root/src/data/invoicing/2024-12-01/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [],];
