<?php
// This file was auto-generated from sdk-root/src/data/pinpoint-sms-voice-v2/2022-03-31/waiters-2.json
return [ 'version' => 2, 'waiters' => [],];
