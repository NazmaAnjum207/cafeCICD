<?php
// This file was auto-generated from sdk-root/src/data/kinesis-video-signaling/2019-12-04/paginators-1.json
return [ 'pagination' => [],];
