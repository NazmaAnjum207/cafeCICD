<?php
namespace Aws\Identity\S3;

use Aws\Credentials\Credentials;

class S3ExpressIdentity extends Credentials {}
